# Route Lab

A mobile-friendly live GPS tracking app built with HTML, CSS, JavaScript, Leaflet and OpenStreetMap.

## Features
- Live GPS tracking
- Latitude and longitude display
- GPS accuracy in metres
- Dots and Heatmap views
- Center map on current location
- Clear collected points
- Responsive mobile design

## Publish with GitHub Pages
1. Create a repository named `route-lab`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then save.
6. Open the HTTPS URL provided by GitHub Pages and allow location access.

## Notes
- GPS requires HTTPS and browser location permission.
- An internet connection is required for the map tiles and external libraries.
- Heatmap intensity is based on GPS points collected during the current page session.
- Location history is not uploaded to a server and disappears when the page is refreshed.
