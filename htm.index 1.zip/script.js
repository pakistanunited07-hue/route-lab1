"use strict";
const $ = (id) => document.getElementById(id);
const statusPill = $("statusPill"), statusText = $("statusText");
const latitudeEl = $("latitude"), longitudeEl = $("longitude"), accuracyEl = $("accuracy");
const startBtn = $("startBtn"), stopBtn = $("stopBtn"), clearBtn = $("clearBtn");
const dotsBtn = $("dotsBtn"), heatBtn = $("heatBtn"), centerBtn = $("centerBtn");
let watchId = null, currentPosition = null, currentView = "dots", firstFix = true;
const points = [], MAX_POINTS = 3000, defaultLocation = [25.033, 121.5654];
const map = L.map("map", { zoomControl:false, preferCanvas:true }).setView(defaultLocation, 12);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom:19,
  attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
L.control.zoom({ position:"bottomright" }).addTo(map);
const dotLayer = L.layerGroup().addTo(map);
const heatLayer = L.heatLayer([], {
  radius:32, blur:24, maxZoom:18, minOpacity:.25, max:1,
  gradient:{ .15:"#2dd4bf", .35:"#a3e635", .55:"#facc15", .75:"#fb923c", 1:"#ef4444" }
});
const userIcon = L.divIcon({ className:"user-location-icon", html:'<div class="user-location-core"></div>', iconSize:[18,18], iconAnchor:[9,9] });
const userMarker = L.marker(defaultLocation, { icon:userIcon, zIndexOffset:1000 });
const accuracyCircle = L.circle(defaultLocation, { radius:0, color:"#0284c7", weight:1.5, fillColor:"#38bdf8", fillOpacity:.1 });
let userHasFix = false;
function setStatus(label, message, live=false) {
  statusPill.textContent = label; statusPill.classList.toggle("live", live); statusText.textContent = message;
}
function drawDots() {
  dotLayer.clearLayers();
  points.forEach((point, index) => {
    const latest = index === points.length - 1;
    L.circleMarker([point.lat, point.lng], {
      radius:latest ? 6 : 4, color:"#fff", weight:latest ? 2 : 1,
      fillColor:latest ? "#0891b2" : "#22d3ee", fillOpacity:.9
    }).addTo(dotLayer);
  });
}
function refreshLayers() {
  if (currentView === "dots") {
    if (!map.hasLayer(dotLayer)) dotLayer.addTo(map);
    if (map.hasLayer(heatLayer)) map.removeLayer(heatLayer);
    drawDots();
  } else {
    if (map.hasLayer(dotLayer)) map.removeLayer(dotLayer);
    if (!map.hasLayer(heatLayer)) heatLayer.addTo(map);
    heatLayer.setLatLngs(points.map(p => [p.lat, p.lng, p.intensity]));
  }
  dotsBtn.classList.toggle("active", currentView === "dots");
  heatBtn.classList.toggle("active", currentView === "heat");
  dotsBtn.setAttribute("aria-pressed", String(currentView === "dots"));
  heatBtn.setAttribute("aria-pressed", String(currentView === "heat"));
}
function handlePosition(position) {
  const lat = position.coords.latitude, lng = position.coords.longitude, accuracy = position.coords.accuracy;
  currentPosition = { lat, lng, accuracy };
  latitudeEl.textContent = lat.toFixed(6); longitudeEl.textContent = lng.toFixed(6);
  accuracyEl.textContent = Number.isFinite(accuracy) ? String(Math.round(accuracy)) : "—";
  userMarker.setLatLng([lat,lng]); accuracyCircle.setLatLng([lat,lng]).setRadius(Number.isFinite(accuracy) ? accuracy : 0);
  if (!userHasFix) { userMarker.addTo(map); accuracyCircle.addTo(map); userHasFix = true; }
  const last = points[points.length - 1];
  const movedEnough = !last || map.distance([last.lat,last.lng], [lat,lng]) >= 2;
  if (movedEnough) {
    points.push({lat,lng,intensity:.7});
    if (points.length > MAX_POINTS) points.shift();
    refreshLayers();
  }
  if (firstFix) { map.setView([lat,lng], 17, {animate:true}); firstFix = false; }
  setStatus("Tracking", "Live GPS location updated.", true);
}
function stopTracking() {
  if (watchId !== null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
  watchId = null; startBtn.disabled = false; stopBtn.disabled = true;
}
function handlePositionError(error) {
  const messages = {
    1:"Location permission denied. Allow location access in browser settings.",
    2:"Location unavailable. Try again outdoors.",
    3:"GPS timed out. Please try again."
  };
  stopTracking(); setStatus("GPS issue", messages[error.code] || "Could not get your location.");
}
function startTracking() {
  if (!navigator.geolocation) { setStatus("Unavailable", "Your browser does not support GPS."); return; }
  if (!window.isSecureContext) { setStatus("HTTPS required", "Open this app using an HTTPS URL."); return; }
  if (watchId !== null) return;
  firstFix = !currentPosition; setStatus("Starting", "Waiting for GPS location…");
  startBtn.disabled = true; stopBtn.disabled = false;
  watchId = navigator.geolocation.watchPosition(handlePosition, handlePositionError, {
    enableHighAccuracy:true, maximumAge:1000, timeout:20000
  });
}
function setView(view) { currentView = view; refreshLayers(); }
startBtn.addEventListener("click", startTracking);
stopBtn.addEventListener("click", () => {
  stopTracking(); setStatus("Stopped", currentPosition ? "Tracking stopped. Last location remains visible." : "Tracking stopped.");
});
dotsBtn.addEventListener("click", () => setView("dots"));
heatBtn.addEventListener("click", () => setView("heat"));
centerBtn.addEventListener("click", () => {
  if (currentPosition) map.setView([currentPosition.lat,currentPosition.lng], Math.max(map.getZoom(),16), {animate:true});
  else map.setView(defaultLocation,12);
});
clearBtn.addEventListener("click", () => {
  points.length = 0; refreshLayers();
  setStatus(watchId !== null ? "Tracking" : "Ready", watchId !== null ? "Cleared dots. GPS tracking continues." : "All collected dots cleared.", watchId !== null);
});
window.addEventListener("resize", () => map.invalidateSize());
refreshLayers();
